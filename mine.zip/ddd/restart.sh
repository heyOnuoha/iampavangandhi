for scr in $(/usr/bin/screen -ls | awk '{print $1}'); do screen -S $scr -X kill; done

cd ~

sudo chmod 777 /bin/ethminer
